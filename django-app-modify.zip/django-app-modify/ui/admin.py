# Register your models here.
from django.contrib import admin
from django import forms

# Register your models here.
from .models import Community, Fee, FeeCategory, CommunityFee, Asset
from django.contrib import admin
from django.contrib.admin.models import LogEntry, DELETION, ADDITION
from django.utils.html import escape
from django.urls import reverse
from django.utils.safestring import mark_safe
from simple_history.admin import SimpleHistoryAdmin
from admin_auto_filters.filters import AutocompleteFilter

@admin.register(LogEntry)
class LogEntryAdmin(admin.ModelAdmin):
    date_hierarchy = 'action_time'

    list_filter = [
        'user',
        'content_type',
        'action_flag'
    ]

    search_fields = [
        'object_repr',
        'change_message'
    ]

    list_display = [
        'action_time',
        'user',
        'content_type',
        # 'object_link',
        'action_flag',
    ]

    # def object_link(self, obj):
    #     if obj.action_flag == DELETION:
    #         link = escape(obj.object_repr)
    #     else:
    #         ct = obj.content_type
    #         link = '<a href="%s">%s</a>' % (
    #             reverse('admin:%s_%s_change' % (ct.app_label, ct.model), args=[obj.object_id]),
    #             escape(obj.object_repr),
    #         )
    #     return mark_safe(link)
    # object_link.admin_order_field = "object_repr"
    # object_link.short_description = "object"

class CommunityAdmin(SimpleHistoryAdmin):
    search_fields = ['community_name']
    exclude = ["created_by","created_dttm","updated_by","update_dttm"]
    list_filter = ('state',)
    list_display = ('community_name', 'address', 'city', 'state', 'phone1')
    list_editable = ( 'address',)
    history_list_display = ['community_name', 'address', 'city', 'state', 'phone1', 'created_dttm', 'updated_dttm']
    list_per_page = 25
    actions_on_bottom =True
    actions_on_top = False    
    # readonly_fields=('cortos_community_id',)

class AssetAdmin(SimpleHistoryAdmin):
    search_fields = ['asset_name']
    exclude = ["created_by","created_dttm","updated_by","update_dttm"]
    autocomplete_fields =['cortos_community']
    # list_filter = ('state',)
    list_display = ('cortos_community','asset_name','asset_type','portfolio',)
    # list_editable = ( 'asset_type')
    history_list_display = ['asset_name', 'asset_type']
    list_per_page = 25
    actions_on_bottom =True
    actions_on_top = False    
    # readonly_fields=('cortos_community_id',)

class FeeCategoryAdminForm(forms.ModelForm):
    class Meta:
        model = FeeCategory
        fields = '__all__'

    def clean(self):
        cleaned_data = super().clean()
        fee_category_code = cleaned_data.get('fee_category_code')
        
        if fee_category_code[0:1] not in ['C','P','I','O']:
            raise forms.ValidationError('Valid First character of Transaction Category are: C, P, I, O')

        return self.cleaned_data
    
class FeeCategoryAdmin(SimpleHistoryAdmin):
    form = FeeCategoryAdminForm
    search_fields = ['fee_category_description']
    exclude = ["fee_category_type","created_by","created_dttm","updated_by","update_dttm"] 
    list_display = ( 'fee_category_code', 'fee_category_description', 'fee_category_type')
    list_filter = ('fee_category_type',)
    history_list_display = ('fee_category_code', 'fee_category_description', 'fee_category_type')
    list_per_page = 25    
    actions_on_bottom =True
    actions_on_top = False  
    def save_model(self, request, obj, form, change):
        match obj.fee_category_code[0:1]:
            case 'C':
                obj.fee_category_type = 'Charges'
            case 'P':
                obj.fee_category_type = 'Payments or Credits'
            case 'I':
                obj.fee_category_type = 'Deposits received(deposit in)'
            case 'O':
                obj.fee_category_type = 'Deposits disbursed(deposit out)'   
            case _:
                obj.fee_category_type = 'Undefined'

        super().save_model(request, obj, form, change)


class FeeAdmin(SimpleHistoryAdmin):
    # radio_fields = {'is_cash_type_code':admin.VERTICAL,
    #                 'allow_charge_back': admin.VERTICAL,
    #                 }
    search_fields = ['transaction_code_description']
    autocomplete_fields =['cortos_fee_category']
    exclude = ["created_by","created_dttm","updated_by","update_dttm"]
    list_display = ('transaction_code', 'transaction_code_description', 'cortos_fee_category', )
    history_list_display = ('cortos_fee_id', 'cortos_fee_category', 'transaction_code', 'transaction_code_description')
    list_per_page = 25    
    actions_on_bottom =True
    actions_on_top = False

class CommunityFeeFilter(AutocompleteFilter):
    title = 'Community Name' # display title
    field_name = 'cortos_community' # name of the foreign key field

class CommunityFeeAdminForm(forms.ModelForm):
    # cortos_fee = forms.ModelChoiceField(queryset=Fee.objects.all(), label='Transaction Code Description')
    # cortos_fee = forms.CharField(label="Trans Code Description")
    class Meta:
        model = CommunityFee
        fields = '__all__'

    def clean(self):
        cleaned_data = super().clean()
        cortos_community = cleaned_data.get('cortos_community')
        cortos_community_phase = cleaned_data.get('cortos_community_phase')
        cortos_fee = cleaned_data.get('cortos_fee')
        movein_start_date = cleaned_data.get('movein_start_date')
        renewal_start_date = cleaned_data.get('renewal_start_date')
        if movein_start_date is None:
            raise forms.ValidationError('Populate effective end date')

        # if CommunityFee.objects.filter(cortos_community=cortos_community,
        #                                cortos_community_phase=cortos_community_phase,
        #                         cortos_fee=cortos_fee, 
        #                         effective_start_date__lte=effective_end_date, 
        #                         effective_end_date__gte=effective_start_date).exclude(pk=self.instance.pk).exists():
        #     raise forms.ValidationError('Fee Code already exists within effective date range')
        return self.cleaned_data
    

class CommunityFeeAdmin(SimpleHistoryAdmin):
    form = CommunityFeeAdminForm
    exclude = ["created_by","created_dttm","updated_by","update_dttm"]
    autocomplete_fields =['cortos_community','cortos_community_phase']
    # list_filter = ('cortos_community',)
    list_filter = [CommunityFeeFilter]
    list_display = ('cortos_community', 'cortos_community_phase', 'cortos_fee', 'billing_frequency', 'fee_type', 'minimum_amount','maximum_amount', 'movein_start_date', 'renewal_start_date')
    list_editable = ('minimum_amount', 'movein_start_date')
    history_list_display = ('cortos_community_fee_id', 'billing_frequency', 'fee_type', 'minimum_amount','maximum_amount', 'movein_start_date', 'renewal_start_date')
    list_per_page = 25
    actions_on_bottom =True
    actions_on_top = False    

admin.site.register(Fee, FeeAdmin)

admin.site.register(Community, CommunityAdmin)

admin.site.register(Asset, AssetAdmin)

admin.site.register(CommunityFee, CommunityFeeAdmin)

admin.site.register(FeeCategory, FeeCategoryAdmin)

