import datetime
from django.db import models
from localflavor.us.models import USStateField
from django.core.exceptions import ValidationError
from simple_history.models import HistoricalRecords
from django.contrib.auth.models import User
from django import forms

# Create your models here.
class Community(models.Model):
    cortos_community_id = models.IntegerField(primary_key=True, unique= True)
    community_asset_id = models.CharField(max_length=50)
    community_name = models.CharField(max_length=40)
    address = models.CharField(max_length=150, null=True)
    city = models.CharField(max_length=20, null=True)
    state = USStateField(max_length=20, blank= True, null=True)
    zip = models.CharField(max_length=10, blank= True, null=True)
    country = models.CharField(max_length=50, default='USA', null=True)
    phone1 = models.CharField(max_length=21, blank= True, null=True)
    phone2 = models.CharField(max_length=21, blank= True, null=True)
    fax = models.CharField(max_length=21, blank= True, null=True)
    email_address = models.EmailField(max_length=50, blank= True, null=True)
    webAddress = models.CharField(max_length=255, blank= True, null=True)
    office_hours = models.CharField(max_length=255, blank= True, null=True)
    cell_signal_rating = models.CharField(max_length=50, blank= True, null=True)
    wifi_gap_area = models.CharField(max_length=50, blank= True, null=True)
    created_by = models.CharField(max_length=100)
    # models.ForeignKey(User, on_delete=models.CASCADE, blank= True)
    created_dttm = models.DateTimeField(auto_now_add=True)
    updated_by = models.CharField(max_length=100)
    updated_dttm = models.DateTimeField(auto_now=True)
    history = HistoricalRecords(table_name='community_audit_log')
    class Meta:
        db_table = "community"
        verbose_name_plural = 'community'

    def __str__(self):
        return f'{self.community_name}'

class Asset(models.Model):
    cortos_asset_id = models.IntegerField(primary_key=True, unique= True)
    cortos_community = models.ForeignKey(Community, on_delete=models.CASCADE, null=True, blank=False)
    asset_id = models.CharField(max_length=50)
    community_asset_id = models.CharField(max_length=50, blank= True, null=True)
    asset_name = models.CharField(max_length=150, unique=True)
    asset_type = models.CharField(max_length=50, blank=True, null=True)
    asset_class = models.CharField(max_length=3, blank=True, null=True)
    asset_style = models.CharField(max_length=50, blank=True, null=True)
    asset_legal_name = models.CharField(max_length=250, blank=True, null=True)
    tax_id = models.CharField(max_length=50, blank=True, null=True)
    acreage = models.DecimalField(max_digits=12, decimal_places=2, blank= True, null=True)
    address = models.CharField(max_length=150, blank=True, null=True)
    city = models.CharField(max_length=20, blank=True, null=True)
    state = USStateField(max_length=20, blank=True, null=True)
    zip = models.CharField(max_length=10, blank=True, null=True)
    country = models.CharField(max_length=50, default='USA', blank=True, null=True)
    investment_strategy = models.CharField(max_length=100, blank=True, null=True)
    portfolio = models.CharField(max_length=50, blank=True, null=True)
    subportfolio = models.CharField(max_length=50, blank=True, null=True)
    fund_name = models.CharField(max_length=250, blank=True, null=True)  
    area_type = models.CharField(max_length=50, blank=True, null=True)
    acquisition_type = models.CharField(max_length=100, blank=True, null=True)
    acquisition_date = models.DateField(null=False, blank=False)
    acquisition_price = models.DecimalField(max_digits=12, decimal_places=2,blank=True, null=True)
    sold_to = models.CharField(max_length=250, blank=True, null=True)
    sale_date = models.DateField(null=True, blank=True)
    sale_price = models.DecimalField(max_digits=12, decimal_places=2,blank=True, null=True)
    equity_partner = models.CharField(max_length=250, blank= True, null=True)
    total_hard_cost = models.DecimalField(max_digits=12, decimal_places=2,blank=True, null=True)
    total_soft_and_closing_cost = models.DecimalField(max_digits=12, decimal_places=2,blank=True, null=True)
    total_project_cost = models.DecimalField(max_digits=12, decimal_places=2,blank=True, null=True)
    basis_of_accounting = models.CharField(max_length=25, blank= True, null=True)
    proforma_levered_irr = models.DecimalField(max_digits=12, decimal_places=6,blank=True, null=True)
    proforma_levered_equity_multiple = models.DecimalField(max_digits=12, decimal_places=6,blank=True, null=True)
    proforma_entry_cap_rate = models.DecimalField(max_digits=12, decimal_places=6,blank=True, null=True)
    proforma_unlevered_irr = models.DecimalField(max_digits=12, decimal_places=6,blank=True, null=True)
    proforma_unlevered_equity_multiple = models.DecimalField(max_digits=12, decimal_places=6,blank=True, null=True)
    fund_ownership_percent = models.DecimalField(max_digits=6, decimal_places=2,blank=True, null=True)
    total_project_cost = models.DecimalField(max_digits=12, decimal_places=2,blank=True, null=True)
    acquisition_development_fee = models.DecimalField(max_digits=12, decimal_places=2,blank=True, null=True)
    construction_management_fee = models.DecimalField(max_digits=12, decimal_places=2,blank=True, null=True)
    property_management_fee = models.DecimalField(max_digits=12, decimal_places=2,blank=True, null=True)
    asset_management_fee_basis = models.DecimalField(max_digits=12, decimal_places=2,blank=True, null=True)
    asset_management_fee_basis = models.CharField(max_length=100, blank= True, null=True)
    asset_management_fee_percent = models.DecimalField(max_digits=12, decimal_places=2,blank=True, null=True)
    created_by = models.CharField(max_length=100, default='django')
    created_dttm = models.DateTimeField(auto_now_add=True)
    updated_by = models.CharField(max_length=100)
    updated_dttm = models.DateTimeField(auto_now=True)
    history = HistoricalRecords(table_name='asset_audit_log')
    class Meta:
        db_table = "asset"
        verbose_name_plural = 'asset'

    def __str__(self):
        return f'{self.asset_name}'


class FeeCategory(models.Model):
     
    cortos_fee_category_id = models.AutoField(primary_key=True)
    fee_category_code = models.CharField(max_length=2, blank=False, verbose_name='Transaction Category')
    fee_category_description = models.CharField(max_length=150, blank=False, verbose_name='Transaction Category Description')
    fee_category_type = models.CharField(max_length=50, blank=True, null = True, verbose_name='Transaction Category Type')
    remarks = models.TextField(max_length=1000, help_text="Limit to 1000 characters", null=True,blank=True)
    created_by = models.CharField(max_length=100, default='django')
    created_dttm = models.DateTimeField(auto_now_add=True)
    updated_by = models.CharField(max_length=100, default='django', null=True)
    updated_dttm = models.DateTimeField(auto_now=True, null=True)
    history = HistoricalRecords(table_name='fee_category_audit_log')   

    class Meta:
        db_table = "fee_category"
        verbose_name_plural = 'Fee Category'
        constraints = [
        models.UniqueConstraint(fields=['fee_category_code', 'fee_category_description'], name='unique code and description')
    ]

    def __str__(self):
        return f'{self.fee_category_code} - {self.fee_category_description}' 

class Fee(models.Model):

    accounting_method_choices = {
        "ACCRUAL": "Accrual",
        "BOTH": "Both",
    } 
    assign_to_rights_choices = {
        "1": "Transaction right 1",
        "2": "Transaction right 2",
        "3": "Transaction right 3",
        "4": "Transaction right 4",
    }   
    cortos_fee_id = models.AutoField(primary_key=True)
    cortos_fee_category = models.ForeignKey(FeeCategory, on_delete=models.CASCADE, null=False, blank=False)    
    transaction_code = models.CharField(max_length=30, null=False, blank=False)
    transaction_code_description = models.CharField(max_length=150, null=False, blank=False)
    fee_display_name = models.CharField(max_length=150, null=True, blank=True, help_text='Fee display name for customer facing applications')    
    default_amount = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=False)
    warning_amount = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=False)
    can_site_override_amount = models.BooleanField(null=True,blank=True,default=False)    
    debit_gl = models.CharField(max_length=50, null=True, blank=True)    
    credit_gl = models.CharField(max_length=50, null=True, blank=True)
    accounting_method = models.CharField(max_length=9, choices=accounting_method_choices, null=True, default='BOTH')
    writeoff_to_self = models.BooleanField(null=True,blank=True,default=False)  
    write_off_transaction_code = models.CharField(max_length=20, null=True, blank=True)
    exempt_write_off_code = models.CharField(max_length=20, null=True, blank=True)
    collections_final_write_off_code = models.CharField(max_length=20, null=True, blank=True)
    assign_to_rights = models.CharField(max_length=20, choices=assign_to_rights_choices, null=True, blank=True)
    is_cash_type_code = models.BooleanField(null=True, blank=True,default=False)
    allow_charge_back = models.BooleanField(null=True,blank=True,default=False)
    transaction_causes_reversal = models.BooleanField(null=False, blank=True, default=False)
    transaction_may_be_reversed = models.BooleanField(null=False,blank=True,default=False)
    group_to_rent = models.BooleanField(null=False,blank=True,default=False)
    access_late_fees = models.BooleanField(null=False,blank=True,default=False)
    do_not_prorate = models.BooleanField(null=False,blank=True,default=False)
    allow_scheduled_billing_dates_overlap = models.BooleanField(null=False,blank=True,default=False)     
    active = models.BooleanField(null=False,blank=False,default=True)        
    remarks = models.TextField(max_length=1000, help_text="Limit to 1000 characters", null=True,blank=True)
    created_by = models.CharField(max_length=100, default='django')
    created_dttm = models.DateTimeField(auto_now_add=True)
    updated_by = models.CharField(max_length=100, default='django', null=True)
    updated_dttm = models.DateTimeField(auto_now=True, null=True)
    history = HistoricalRecords(table_name='fee_audit_log')

    class Meta:
        db_table = "fee"
        verbose_name_plural = 'Fee'

    def __str__(self):
        return f'{self.transaction_code_description}'
    

class CommunityFee(models.Model):
    display_category_choices = {
        "REQUIRED" : "Required",
        "ADDON" : "Add-on",
    }
    category_choices = {
        "MANDATORY" : "Mandatory",
        "OPTIONAL" : "Optional",
    }    
    type_choices = {
        "APPLICATION": "Application",
        "MOVEIN": "Move-in",
        "TRANSFER": "Transfer",
        "FINAL": "Final Statement",
    }
    fee_charge_designation_choices = {
        "DOLLPERPET": "Dollar amount - Per Pet",
        "DOLLPERVEH": "Dollar amount – Per vehicle",
        "DOLLPERLS": "Dollar amount – Per lease signer",
        "DOLLPERPROS": "Dollar amount – Per prospect/household",
        "DOLLBED": "Flat Rate - By Bedroom",
        "DOLLBED": "Flat Rate - By Unit",
        "DOLLBED": "Flat Rate - Dollar",
        "RUBSCMSO": "RUBS - 50% Custom Multiplier, 50% Straight Occupants",
        "RUBSFOSF": "RUBS - 50% Factored Occupancy, 50% Square Footage",
        "RUBSSFBB": "RUBS - 50% Square Footage, 50% By Bedroom",
        # "RUBSCMSO": "RUBS - 50% Square Footage, 50% Factored Occupancy",
        "RUBSSFSF": "RUBS - 50% Square Footage, 50% Square Footage",
        "RUBSSFSO": "RUBS - 50% Square Footage, 50% Straight Occupants",
        "RUBSDA": "RUBS - Dollar Amount",
        "RUBSFO": "RUBS - Factored Occupancy",
        "RUBSPA": "RUBS - Per Apt.",
        "RUBSSF": "RUBS - Square Footage",
        "PERCTOFACTRENT": "% of Actual rent - Per prospect/household",
        "PERCTOFMKTRENT": "% of Market rent - Per prospect/household",
    } 
    billing_frequency_choices = {
        "ONETIME": "One-Time",
        "MONTHLY": "Monthly",
    } 
    billing_source_choices = {
        "ONESITE" : "OneSite",
        "CONSERVICE" : "Conservice",
    } 
    accounting_method_choices = {
        "ACCRUAL": "Accrual",
        "BOTH": "Both",
    }           
    cortos_community_fee_id = models.AutoField(primary_key=True)
    cortos_community = models.ForeignKey(Community, on_delete=models.CASCADE, null=False, blank=False, verbose_name='Community Name')   
    cortos_community_phase = models.ForeignKey(Asset, to_field='asset_name', on_delete=models.CASCADE, null=True, blank=True, default='All', verbose_name='Asset Phase', help_text='Mention Phase number if <em>Amount</em> different for each Phase') 
    cortos_fee = models.ForeignKey(Fee, on_delete=models.CASCADE, null=False, blank=False, verbose_name='Trans Code Description') 
    fee_description = models.CharField(max_length=150, null=True, blank=True, verbose_name='Community Trans Code Description', help_text='Overide fee description for community')   
    fee_category = models.CharField(max_length=15, choices=category_choices, null=True, blank=False)
    fee_display_category = models.CharField(max_length=15, choices=display_category_choices, null=True, blank=False)
    transaction_category_priority = models.IntegerField(null=True, blank=True)
    fee_type = models.CharField(max_length=15, choices=type_choices, null=True, blank=False)
    fee_charge_designation = models.CharField(max_length=30, choices=fee_charge_designation_choices,null=False, blank=False)
    billing_frequency = models.CharField(max_length=15, choices=billing_frequency_choices,null=False, blank=False)
    billing_source = models.CharField(max_length=20, choices=billing_source_choices, null=True, blank=False, default='O')
    minimum_amount = models.DecimalField(max_digits=8, decimal_places=2, null=False, blank=False)
    maximum_amount = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    max_allowed_count = models.IntegerField(null=True, blank=True)
    override_debit_gl = models.CharField(max_length=20, null=True, blank=True)
    override_credit_gl = models.CharField(max_length=20, null=True, blank=True)
    accounting_method = models.CharField(max_length=9, choices=accounting_method_choices, null=True, default='BOTH')      
    movein_start_date = models.DateField(null=False, blank=False, default=datetime.date.today)
    renewal_start_date = models.DateField(null=False, blank=False, default=datetime.date.today)
    display_on_quote_new_lease = models.BooleanField(null=True, blank=True, default=False)
    display_on_quote_renewal = models.BooleanField(null=True, blank=True, default=False)   
    cad_percent = models.DecimalField(max_digits=4, decimal_places=2, null=True, blank=True)
    cortos_floor_plan_id = models.CharField(max_length=150, null=True, blank=True)
    remarks = models.TextField(max_length=200, help_text="Limit to 200 characters", null=True,blank=True)
    created_by = models.CharField(max_length=100, default='django')
    created_dttm = models.DateTimeField(auto_now_add=True)
    updated_by = models.CharField(max_length=100, default='django', null=True)
    updated_dttm = models.DateTimeField(auto_now=True, null=True)    
    history = HistoricalRecords(table_name='community_fee_audit_log')


    class Meta:
        db_table = "community_fee"
        verbose_name_plural = 'Community Fee'

    def __str__(self):
        return f'{self.cortos_community}: {self.cortos_fee}'