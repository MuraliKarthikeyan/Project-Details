# django-app
This repo will host the django app for mdm project

# How to run the project Locally

1. Create a .env file in the root of the project
2. Define the following env vars
```
SECRET_KEY=some_key
DB_NAME=some_dbname
DB_USER=some_user
DB_PASSWORD=some_password
DB_HOST=some_host
DB_PORT=some_port
```

3. Run `pipenv install` to install all packages in pipfile.
4. Start the application environment: `pipenv shell`
5. If there are any database changes, perform the below, else continue to Step 5:
    `python manage.py makemigrations` (Use `python manage.py makemigrations ui`) after deleting migrations folder
    ` python manage.py migrate`
6. Build and run docker image using docker compose: `docker compose -f docker-compose.local.yml up --build`
7. If you just want to run the container without building again, type: `docker compose -f docker-compose.local.yml up`
8. Navigate to http://localhost:8000/mdm
9. **For a new database, remember to create superuser: `python manage.py createsuperuser`